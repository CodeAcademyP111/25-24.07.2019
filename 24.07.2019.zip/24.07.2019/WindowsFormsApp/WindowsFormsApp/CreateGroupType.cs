﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp.Model;

namespace WindowsFormsApp
{
    public partial class CreateGroupType : Form
    {
        private P111Entities db;
        private ComboBox Cmb;
        public CreateGroupType(ComboBox cmb)
        {
            Cmb = cmb;
            InitializeComponent();
            db = new P111Entities();
        }

        private async void btnCreateStu_Click(object sender, EventArgs e)
        {
            CheckInput();
            string grouptype = txtGroupType.Text.Trim();
            if(!db.GroupTypes.Any(gt=>gt.TypeName== grouptype))
            {
                db.GroupTypes.Add(new GroupType { TypeName = grouptype });
                await db.SaveChangesAsync();
                MessageBox.Show("Succesfully added", "Succes", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show($"{grouptype} already exist !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void CheckInput()
        {
            string grouptype = txtGroupType.Text.Trim();

            if (grouptype == "")
            {
                MessageBox.Show("Fill all input", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void CreateGroupType_Load(object sender, EventArgs e)
        {

        }

        private void CreateGroupType_FormClosing(object sender, FormClosingEventArgs e)
        {
            Cmb.DataSource = null;
            Cmb.DataSource = db.GroupTypes
                .Select(gt => new CB_class { Id = gt.Id, Name = gt.TypeName }).ToArray();
        }
    }
}
