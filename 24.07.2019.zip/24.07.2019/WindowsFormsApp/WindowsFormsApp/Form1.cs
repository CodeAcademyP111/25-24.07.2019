﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp.Model;

namespace WindowsFormsApp
{
    public partial class Form1 : Form
    {
        private P111Entities db;
        private Student std;
        private Student student_update_delete;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            db = new P111Entities();
            FillDGV();
            cmbGroupType.Items.AddRange(db.GroupTypes
                .Select(gt => new CB_class { Id=gt.Id,Name=gt.TypeName}).ToArray());
            

        }

        private void FillDGV()
        {
            var students = db.Students.Where(st=>st.Deleted==false).Select(s => new
            {
                s.Id,
                s.Name,
                s.Surname,
                Gruop = s.Group.GroupName,
                Type = s.Group.GroupType.TypeName
            }).OrderByDescending(s=>s.Id).ToList();

            dgvDetailStu.DataSource = students;
        }

        private void CmbGroupType_SelectedValueChanged(object sender, EventArgs e)
        {
            cmbGroup.Text = null;
            int groupTypeId = (cmbGroupType.SelectedItem as CB_class).Id;

            cmbGroup.DataSource = db.Groups.Where(gr => gr.GroupTypeId == groupTypeId)
                .Select(gr => new CB_class { Id = gr.Id, Name = gr.GroupName }).ToList();
        }

        private async void Button1_Click(object sender, EventArgs e)
        {
            CheckInput();

            db.Students.Add(std);
            await db.SaveChangesAsync();
            MessageBox.Show("Succesfully added", "Succes", MessageBoxButtons.OK, MessageBoxIcon.Information);

            UpdateDataGridView();
        }

        private void dgvDetailStu_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int Id = (int)dgvDetailStu.Rows[e.RowIndex].Cells[0].Value;
            student_update_delete = db.Students.Find(Id);
            txtNameStu.Text = student_update_delete.Name;
            txtSurnameStu.Text = student_update_delete.Surname;
            cmbGroup.Text = student_update_delete.Group.GroupName;
            cmbGroupType.Text = student_update_delete.Group.GroupType.TypeName;
            btnVisible(true);
        }

        private void btnVisible(bool b)
        {
            if (b)
            {
                btnCreateStu.Visible = false;
                btnDeleteStu.Visible = true;
                btnUpdateStu.Visible = true;
            }
            else
            {
                btnCreateStu.Visible = true;
                btnDeleteStu.Visible = false;
                btnUpdateStu.Visible = false;
            }
        }

        private void createToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnVisible(false);
        }

        private async void btnUpdateStu_Click(object sender, EventArgs e)
        {
            CheckInput();

            student_update_delete.Name = std.Name;
            student_update_delete.Surname = std.Surname;
            student_update_delete.GroupsId = std.GroupsId;
            await db.SaveChangesAsync();

            UpdateDataGridView();
        }

        private void CheckInput()
        {
            string name = txtNameStu.Text.Trim();
            string surname = txtSurnameStu.Text.Trim();
            int? groupId = (cmbGroup.SelectedItem as CB_class).Id;

            if (name == "" || surname == "" || groupId == null)
            {
                MessageBox.Show("Fill all input", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                std = new Student { Name = name, Surname = surname, GroupsId = groupId };
            }

            
        }

        private void UpdateDataGridView()
        {
            dgvDetailStu.DataSource = null;
            FillDGV();
            txtNameStu.Text = null;
            txtSurnameStu.Text = null;
        }

        private async void btnDeleteStu_Click(object sender, EventArgs e)
        {
            DialogResult response =MessageBox.Show($"Are you sure delete {student_update_delete.Name} ?", "Warning !",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (response == DialogResult.Yes)
            {
                student_update_delete.Deleted = true;
                await db.SaveChangesAsync();
                UpdateDataGridView();
                MessageBox.Show("Succesfully deleted", "Succes", MessageBoxButtons.OK, MessageBoxIcon.Information);
            } 
        }

        private void createToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            CreateGroupType gt = new CreateGroupType(cmbGroupType);
            gt.ShowDialog();
        }
    }
}
