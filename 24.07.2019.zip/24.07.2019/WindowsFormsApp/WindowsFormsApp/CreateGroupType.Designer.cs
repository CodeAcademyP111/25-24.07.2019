﻿namespace WindowsFormsApp
{
    partial class CreateGroupType
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtGroupType = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCreateStu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtGroupType
            // 
            this.txtGroupType.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtGroupType.Location = new System.Drawing.Point(51, 73);
            this.txtGroupType.Name = "txtGroupType";
            this.txtGroupType.Size = new System.Drawing.Size(169, 26);
            this.txtGroupType.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.DarkRed;
            this.label3.Location = new System.Drawing.Point(47, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Group Type :";
            // 
            // btnCreateStu
            // 
            this.btnCreateStu.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCreateStu.ForeColor = System.Drawing.Color.DarkRed;
            this.btnCreateStu.Location = new System.Drawing.Point(51, 151);
            this.btnCreateStu.Name = "btnCreateStu";
            this.btnCreateStu.Size = new System.Drawing.Size(169, 42);
            this.btnCreateStu.TabIndex = 11;
            this.btnCreateStu.Text = "Create Group Type";
            this.btnCreateStu.UseVisualStyleBackColor = true;
            this.btnCreateStu.Click += new System.EventHandler(this.btnCreateStu_Click);
            // 
            // CreateGroupType
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnCreateStu);
            this.Controls.Add(this.txtGroupType);
            this.Controls.Add(this.label3);
            this.Name = "CreateGroupType";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CreateGroupType";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CreateGroupType_FormClosing);
            this.Load += new System.EventHandler(this.CreateGroupType_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtGroupType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCreateStu;
    }
}